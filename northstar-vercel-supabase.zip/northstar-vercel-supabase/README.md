# Northstar Markets — iPhone-friendly one-click deployment

This version is designed for a simple cloud deployment using **Vercel + Supabase Auth**. It does not require Node/PostgreSQL on your iPhone.

## 1. Create the authentication backend
Create a Supabase project. In Authentication, enable email/password authentication. Supabase Auth handles password storage, sessions and email verification.

Copy your project's URL and **publishable key** from the Supabase project settings.

## 2. Configure the site
Open `public/config.js` and replace:
- `PASTE_YOUR_SUPABASE_PROJECT_URL`
- `PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY`

Do NOT put a Supabase `service_role`/secret key in this file.

## 3. Deploy from iPhone
Upload this folder to a GitHub repository using Safari/GitHub. Then import the repository into Vercel and deploy it. Vercel's Deploy Button can also be used when the project is published in a Git repository.

After deployment, set the Supabase Auth Site URL and Redirect URLs to your Vercel domain, e.g. `https://your-project.vercel.app`.

## Important
This is an authentication/portal demo, not a live brokerage. Do not collect deposits, investment funds, payment credentials, or claim regulatory authorization unless you actually have the required licenses and infrastructure. Before real financial use, add compliance/KYC/AML, MFA, audit logging, secure server-side authorization, broker/custodian integration and production security controls.

Supabase password authentication and sessions are documented at:
https://supabase.com/docs/guides/auth
