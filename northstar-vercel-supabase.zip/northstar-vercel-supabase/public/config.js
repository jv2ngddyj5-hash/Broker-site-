// Paste the public values from Supabase here.
// These are safe to expose in a browser when using Supabase RLS correctly.
window.SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL";
window.SUPABASE_PUBLISHABLE_KEY = "PASTE_YOUR_SUPABASE_PUBLISHABLE_KEY";