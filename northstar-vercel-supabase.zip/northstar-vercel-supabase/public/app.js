const configured =
  window.SUPABASE_URL &&
  window.SUPABASE_PUBLISHABLE_KEY &&
  !window.SUPABASE_URL.startsWith("PASTE_") &&
  !window.SUPABASE_PUBLISHABLE_KEY.startsWith("PASTE_");

const message = document.getElementById("message");
const form = document.getElementById("authForm");
const email = document.getElementById("email");
const password = document.getElementById("password");
const title = document.getElementById("title");
const subtitle = document.getElementById("subtitle");
const submit = document.getElementById("submit");
const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");
const toggle = document.getElementById("toggle");
const forgot = document.getElementById("forgot");

let register = false;
const supabase = configured
  ? window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_PUBLISHABLE_KEY)
  : null;

function show(text, error = false) {
  message.textContent = text;
  message.className = "message " + (error ? "error" : "success");
}
function mode(v) {
  register = v;
  loginTab.classList.toggle("active", !v);
  registerTab.classList.toggle("active", v);
  title.textContent = v ? "Create your account" : "Welcome back";
  subtitle.textContent = v ? "Open your secure brokerage portal." : "Sign in to continue to your trading account.";
  submit.innerHTML = v ? "Create account <span>→</span>" : "Sign in <span>→</span>";
  password.autocomplete = v ? "new-password" : "current-password";
  show("");
}
loginTab.onclick = () => mode(false);
registerTab.onclick = () => mode(true);
toggle.onclick = () => {
  password.type = password.type === "password" ? "text" : "password";
  toggle.textContent = password.type === "password" ? "Show" : "Hide";
};

forgot.onclick = async () => {
  if (!configured) return show("Add your Supabase settings in config.js first.", true);
  if (!email.value) return show("Enter your email address first.", true);
  const { error } = await supabase.auth.resetPasswordForEmail(email.value, {
    redirectTo: window.location.origin + "/reset.html"
  });
  show(error ? error.message : "If the account exists, a password-reset email has been sent.");
};

form.onsubmit = async (e) => {
  e.preventDefault();
  if (!configured) return show("Setup required: add your Supabase URL and publishable key in config.js.", true);

  submit.disabled = true;
  if (register) {
    const { error } = await supabase.auth.signUp({
      email: email.value.trim(),
      password: password.value,
      options: { emailRedirectTo: window.location.origin }
    });
    if (error) show(error.message, true);
    else show("Account created. Check your email if confirmation is enabled.");
  } else {
    const { error } = await supabase.auth.signInWithPassword({
      email: email.value.trim(),
      password: password.value
    });
    if (error) show("Unable to sign in. Check your credentials and email verification.", true);
    else window.location.href = "/dashboard.html";
  }
  submit.disabled = false;
};